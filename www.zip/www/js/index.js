/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
let app = {
    pages: null,

    init: function () {

        
        if (window.hasOwnProperty("cordova")) {
            console.log("You're on a mobile device");
        }
        let isReady = (window.hasOwnProperty("cordova")) ? 'deviceready' : 'DOMContentLoaded';
        document.addEventListener(isReady, () => {
            app.pages = document.querySelectorAll('.page');
            app.pages[1].classList.add('active');
            
            app.pages.forEach(page => {
                page.querySelector('h1').addEventListener('click', app.navigate);
                document.getElementById('btn').addEventListener('click', app.takephoto);
                document.getElementById('btn').addEventListener('click', app.input);
            });
            
        });
    },
    takephoto: function () {
        let options = {
            destinationType: Camera.DestinationType.FILE_URI,
            sourceType: Camera.PictureSourceType.CAMERA,
            cameraDirection: Camera.Direction.BACK,
            quality:80,
            encodingType: Camera.EncodingType.JPEG,
            targetWidth: 300,
            targetHeight: 400
        };

        navigator.camera.getPicture(app.ftw, app.wtf, options)
       
    },

  

    ftw: function (imgURI) {
        document.getElementById("msg").textContent = imgURI;
        document.getElementById("photo").src = imgURI;
    },

    wtf: function (msg) {
        document.getElementById("msg").textContent = msg;
    },

    


    navigate: function (ev) {
        ev.preventDefault();
        let tapped = ev.currentTarget; //the clicked h1
        console.log(tapped);

        document.querySelector('.active').classList.remove('active');
        //hide the only active page
        let target = tapped.getAttribute('data-target');
        document.getElementById(target).classList.add('active');
       



    },
   
    
};


app.init();
